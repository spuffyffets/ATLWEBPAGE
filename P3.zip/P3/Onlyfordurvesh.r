# Install package if not already installed
# install.packages('shiny')

library(shiny)

# Define the UI
ui <- fluidPage(
  
  titlePanel("Welcome to my project"),
  
  sidebarLayout(
    
    sidebarPanel(
      
      textInput("name", "Enter your name", ""),
      numericInput("age", "Enter your age", value = 18, min = 1, max = 100),
      actionButton("submit", "Submit")
      
    ),
    
    mainPanel(
      
      h1("Output:"),
      textOutput("greeting"),
      textOutput("age_message")
    )
  )
)

# Define the server logic
server <- function(input, output, session) {
  
  observeEvent(input$submit, {
    
    name <- input$name
    age <- input$age
    
    output$greeting <- renderText({
      if (name != '') {
        paste("Hello", name, "!")
      } else {
        "Please enter your name."
      }
    })
    
    output$age_message <- renderText({
      if (age >= 18) {
        paste("You are an adult.")
      } else {
        paste("You are not an adult.")
      }
    })
  })
}

# Run the application 
shinyApp(ui = ui, server = server)